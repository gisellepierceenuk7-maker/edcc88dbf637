// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bless snapshot"); }
int main(){
  announce();
  return lionss_run_workload("SnapshotBless");
}
