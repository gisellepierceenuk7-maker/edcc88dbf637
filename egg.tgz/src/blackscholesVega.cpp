// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compute option vega\n", stdout);
  return lionss_run_workload("blackscholesVega");
}
