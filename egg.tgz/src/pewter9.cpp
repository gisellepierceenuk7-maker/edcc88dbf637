// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cast pewter components\n", stdout);
  return lionss_run_workload("pewter9");
}
