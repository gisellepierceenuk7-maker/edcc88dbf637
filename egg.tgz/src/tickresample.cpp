// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Resample to 1s bars\n", stdout);
  return lionss_run_workload("tickresample");
}
