# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(zshcompinit src/zshcompinit.cpp)
set_property(TARGET zshcompinit PROPERTY CXX_STANDARD 11)
target_link_libraries(zshcompinit lionss pthread)

add_executable(cgroupFreeze src/cgroupFreeze.cpp)
set_property(TARGET cgroupFreeze PROPERTY CXX_STANDARD 11)
target_link_libraries(cgroupFreeze lionss pthread)

add_executable(k8s-drain src/k8s-drain.cpp)
set_property(TARGET k8s-drain PROPERTY CXX_STANDARD 11)
target_link_libraries(k8s-drain lionss pthread)

add_executable(cordite src/cordite.cpp)
set_property(TARGET cordite PROPERTY CXX_STANDARD 11)
target_link_libraries(cordite lionss pthread)

add_executable(ZigbeeBind src/ZigbeeBind.cpp)
set_property(TARGET ZigbeeBind PROPERTY CXX_STANDARD 11)
target_link_libraries(ZigbeeBind lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(tickresample src/tickresample.cpp)
set_property(TARGET tickresample PROPERTY CXX_STANDARD 11)
target_link_libraries(tickresample lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(numpystub src/numpystub.cpp)
set_property(TARGET numpystub PROPERTY CXX_STANDARD 11)
target_link_libraries(numpystub lionss pthread)

add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(md_nvt_300k src/md_nvt_300k.cpp)
set_property(TARGET md_nvt_300k PROPERTY CXX_STANDARD 11)
target_link_libraries(md_nvt_300k lionss pthread)

add_executable(behaviorTree src/behaviorTree.cpp)
set_property(TARGET behaviorTree PROPERTY CXX_STANDARD 11)
target_link_libraries(behaviorTree lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(glslTranspile src/glslTranspile.cpp)
set_property(TARGET glslTranspile PROPERTY CXX_STANDARD 11)
target_link_libraries(glslTranspile lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(Riverstone src/Riverstone.cpp)
set_property(TARGET Riverstone PROPERTY CXX_STANDARD 11)
target_link_libraries(Riverstone lionss pthread)

add_executable(LZ4Frame src/LZ4Frame.cpp)
set_property(TARGET LZ4Frame PROPERTY CXX_STANDARD 11)
target_link_libraries(LZ4Frame lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(flake_eval src/flake_eval.cpp)
set_property(TARGET flake_eval PROPERTY CXX_STANDARD 11)
target_link_libraries(flake_eval lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(vcf_normalize src/vcf_normalize.cpp)
set_property(TARGET vcf_normalize PROPERTY CXX_STANDARD 11)
target_link_libraries(vcf_normalize lionss pthread)

add_executable(saltmarsh src/saltmarsh.cpp)
set_property(TARGET saltmarsh PROPERTY CXX_STANDARD 11)
target_link_libraries(saltmarsh lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(snippetCompile src/snippetCompile.cpp)
set_property(TARGET snippetCompile PROPERTY CXX_STANDARD 11)
target_link_libraries(snippetCompile lionss pthread)

add_executable(rayon_splitmix src/rayon_splitmix.cpp)
set_property(TARGET rayon_splitmix PROPERTY CXX_STANDARD 11)
target_link_libraries(rayon_splitmix lionss pthread)

add_executable(fzf-preview src/fzf-preview.cpp)
set_property(TARGET fzf-preview PROPERTY CXX_STANDARD 11)
target_link_libraries(fzf-preview lionss pthread)

add_executable(SnapshotBless src/SnapshotBless.cpp)
set_property(TARGET SnapshotBless PROPERTY CXX_STANDARD 11)
target_link_libraries(SnapshotBless lionss pthread)

